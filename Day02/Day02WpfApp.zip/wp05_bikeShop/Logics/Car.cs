﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace wp05_bikeShop.Logics
{
    internal class Car
    {
        public string Names { get; set; }    // Auto Property
        public double Speed { get; set; }
        public Color Colors { get; set; }
        public Human Driver { get; set; }
    }
}
